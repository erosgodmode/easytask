-- Run this ONCE in MySQL Workbench if you already created the database earlier
USE easytask;
ALTER TABLE users ADD COLUMN email VARCHAR(120) NULL UNIQUE, ADD COLUMN password_hash VARCHAR(100) NULL;
ALTER TABLE habits ADD COLUMN color VARCHAR(7) NOT NULL DEFAULT '#2D5BFF';
