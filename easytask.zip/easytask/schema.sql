-- Fresh install: run this whole file in MySQL Workbench (lightning bolt button)
-- (If you already ran the old version, run upgrade.sql instead.)
CREATE DATABASE IF NOT EXISTS easytask CHARACTER SET utf8mb4;
USE easytask;

CREATE TABLE IF NOT EXISTS users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(80) NOT NULL,
  email VARCHAR(120) NULL UNIQUE,
  password_hash VARCHAR(100) NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS habits (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  title VARCHAR(120) NOT NULL,
  target_time TIME NOT NULL DEFAULT '08:00:00',
  frequency ENUM('daily','weekdays','weekends','custom','monthly') NOT NULL DEFAULT 'daily',
  days VARCHAR(20) NULL,
  color VARCHAR(7) NOT NULL DEFAULT '#2D5BFF',
  archived TINYINT(1) NOT NULL DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS habit_logs (
  id INT AUTO_INCREMENT PRIMARY KEY,
  habit_id INT NOT NULL,
  log_date DATE NOT NULL,
  completed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY one_log_per_day (habit_id, log_date),
  FOREIGN KEY (habit_id) REFERENCES habits(id) ON DELETE CASCADE
);
