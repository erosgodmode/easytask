// Keeps the app opening when there is no internet (network first, cache as backup)
const C = 'easytask-v2';
self.addEventListener('install', e => e.waitUntil(caches.open(C).then(c => c.addAll(['/', '/style.css', '/app.js']))));
self.addEventListener('fetch', e => {
  const u = new URL(e.request.url);
  if (e.request.method !== 'GET' || u.pathname.startsWith('/api')) return;
  e.respondWith(fetch(e.request)
    .then(r => { const copy = r.clone(); caches.open(C).then(c => c.put(e.request, copy)); return r; })
    .catch(() => caches.match(e.request)));
});
