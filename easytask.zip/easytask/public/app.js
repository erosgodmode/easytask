const $ = s => document.querySelector(s);
const QUOTES = ['Small steps, taken daily, add up.', 'Show up today. That is the whole job.', 'A streak is just a lot of ordinary days.', 'Do the next small thing.', 'Progress beats perfect.', 'Future you will thank you.'];
const COLORS = ['#2D5BFF', '#12A06B', '#E4572E', '#9B5DE5', '#E09F00', '#D6336C'];
const CHK = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12.5l4.5 4.5L19 7"/></svg>';
const FREQ = { daily: 'Every day', weekdays: 'Weekdays', weekends: 'Weekends' };
let A = JSON.parse(localStorage.getItem('et-auth') || 'null'), S, flushing = false, mode = 'login';

const key = () => 'easytask-' + A.user.id;
const save = () => localStorage.setItem(key(), JSON.stringify(S));
const pad = n => String(n).padStart(2, '0');
const ymd = d => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
const ago = n => { const d = new Date(); d.setDate(d.getDate() - n); return d; };
const today = () => ymd(new Date());
const esc = s => s.replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const done = (h, d) => h.logs.includes(d);
const due = (h, d) => {
  if (ymd(d) < h.created) return false;
  const w = d.getDay();
  switch (h.frequency) {
    case 'daily': return true;
    case 'weekdays': return w > 0 && w < 6;
    case 'weekends': return w === 0 || w === 6;
    case 'custom': return (h.days || '').split(',').includes(String(w));
    case 'monthly': return d.getDate() === Math.min(+h.days || 1, new Date(d.getFullYear(), d.getMonth() + 1, 0).getDate());
  }
  return false;
};
const DN = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
const ord = n => n + ([, 'st', 'nd', 'rd'][n % 10 > 3 ? 0 : (n % 100 - n % 10 !== 10) * (n % 10)] || 'th');
const freq = h => h.frequency === 'custom'
  ? (h.days || '').split(',').filter(Boolean).sort((a, b) => ((+a + 6) % 7) - ((+b + 6) % 7)).map(x => DN[x]).join(', ')
  : h.frequency === 'monthly' ? `Monthly on the ${ord(+h.days || 1)}` : FREQ[h.frequency];
const byTime = (a, b) => a.time.localeCompare(b.time);
let mOff = 0, sel = ymd(new Date());
const chip = (h, k) => `<div class="chip ${done(h, k) ? 'd' : ''}" style="--c:${h.color || '#2D5BFF'}"><i></i>${esc(h.title)}<small>${h.time}</small></div>`;
const streak = h => {
  let n = 0;
  for (let i = done(h, today()) ? 0 : 1; i < 400; i++) {
    const d = ago(i);
    if (ymd(d) < h.created) break;
    if (!due(h, d)) continue;
    if (done(h, ymd(d))) n++; else break;
  }
  return n;
};
const dayRate = d => {
  const l = S.habits.filter(h => due(h, d));
  return l.length ? l.filter(h => done(h, ymd(d))).length / l.length : null;
};

// ---- Screens ----
function boot() {
  $('#auth').hidden = !!A; $('#app').hidden = !A;
  if (!A) return;
  S = JSON.parse(localStorage.getItem(key()) || '{"habits":[],"queue":[]}');
  $('#avatar').textContent = A.user.name.trim()[0].toUpperCase();
  $('#uname').textContent = A.user.name; $('#uemail').textContent = A.user.email;
  render(); showNotify(); flush();
}
function logout() { localStorage.removeItem('et-auth'); A = null; boot(); }

function render() {
  const t = today(), now = new Date(), hr = now.getHours();
  const list = S.habits.filter(h => due(h, now)).sort((a, b) => a.time.localeCompare(b.time));
  const n = list.filter(h => done(h, t)).length, pct = list.length ? Math.round(n / list.length * 100) : 0;
  $('#hello').textContent = `Good ${hr < 12 ? 'morning' : hr < 18 ? 'afternoon' : 'evening'}, ${A.user.name.split(' ')[0]}`;
  $('#quote').textContent = QUOTES[now.getDate() % QUOTES.length];
  $('#ring').style.setProperty('--p', pct); $('#ring b').textContent = pct + '%';
  $('#date').textContent = now.toLocaleDateString(undefined, { weekday: 'long', month: 'long', day: 'numeric' });
  $('#summary').textContent = !list.length ? 'Nothing scheduled today.' : n === list.length ? 'All done for today. Nice work.' : `${n} of ${list.length} habits done today.`;
  $('#s-streak').textContent = Math.max(0, ...S.habits.map(streak));
  $('#s-habits').textContent = S.habits.length;
  $('#s-checks').textContent = S.habits.reduce((a, h) => a + h.logs.length, 0);
  $('#status').textContent = !navigator.onLine ? `Offline · ${S.queue.length} change${S.queue.length === 1 ? '' : 's'} saved on this device` : S.queue.length ? 'Syncing…' : 'Online · synced';
  $('#status').className = navigator.onLine ? '' : 'off';

  const c = h => `style="--c:${h.color || '#2D5BFF'}"`;
  $('#today').innerHTML = list.length ? list.map(h => `<li class="row ${done(h, t) ? 'done' : ''}" ${c(h)}>
    <button class="check" data-id="${h.id}" aria-pressed="${done(h, t)}" aria-label="Mark ${esc(h.title)} done">${CHK}</button>
    <div class="t"><strong>${esc(h.title)}</strong><small>${h.time} · ${freq(h)}</small></div>
    ${streak(h) ? `<span class="pill">${streak(h)} in a row</span>` : ''}</li>`).join('')
    : '<p class="empty">No habits for today. Open My habits to add your first one.</p>';

  const off = S.habits.filter(h => !due(h, now));
  $('#offH').hidden = !off.length;
  $('#off').innerHTML = off.map(h => `<li class="row off" ${c(h)}><div class="t"><strong>${esc(h.title)}</strong><small>${h.time} · ${freq(h)} · not scheduled today</small></div></li>`).join('');
  const seg = d => S.habits.filter(h => due(h, d)).map(h => `<b style="background:${done(h, ymd(d)) ? (h.color || '#2D5BFF') : '#DCE3F0'}"></b>`).join('');
  $('#week').innerHTML = [6, 5, 4, 3, 2, 1, 0].map(i => `<div class="bar-c"><div class="col">${seg(ago(i)) || '<b class="none"></b>'}</div><span class="${i === 0 ? 'tdy' : ''}">${ago(i).toLocaleDateString(undefined, { weekday: 'short' })}<br>${ago(i).getDate()}</span></div>`).join('');
  const dow = (now.getDay() + 6) % 7; // Monday = 0
  $('#month').innerHTML = Array.from({ length: 28 }, (_, k) => {
    const d = ago(dow + 21 - k), key = ymd(d), r = dayRate(d), fut = key > t;
    const lab = d.getDate() === 1 ? d.toLocaleDateString(undefined, { month: 'short', day: 'numeric' }) : d.getDate();
    return `<i class="${fut ? 'fut' : ''} ${key === t ? 'today' : ''}" title="${d.toDateString()}: ${fut ? 'upcoming' : r === null ? 'nothing scheduled' : Math.round(r * 100) + '% done'}">${fut ? '' : seg(d)}<em>${lab}</em></i>`;
  }).join('');
  $('#stats').innerHTML = S.habits.length ? S.habits.map(h => {
    let s = 0, k = 0;
    for (let i = 0; i < 30; i++) { const d = ago(i); if (due(h, d)) { s++; if (done(h, ymd(d))) k++; } }
    return `<li class="row" ${c(h)}><div class="t"><strong>${esc(h.title)}</strong><small>${s ? Math.round(k / s * 100) : 0}% completed in the last 30 days</small></div><span class="pill">${streak(h)} in a row</span></li>`;
  }).join('') : '<p class="empty">Progress shows up here once you add habits.</p>';
  $('#habitList').innerHTML = S.habits.length ? S.habits.map(h => `<li class="row" ${c(h)}><div class="t"><strong>${esc(h.title)}</strong><small>${h.time} · ${freq(h)}</small></div>
    <button class="del" data-id="${h.id}" aria-label="Delete ${esc(h.title)}">Delete</button></li>`).join('') : '<p class="empty">You have no habits yet.</p>';
  renderWeek(); renderMonth();
}

function renderWeek() {
  $('#weekList').innerHTML = Array.from({ length: 7 }, (_, i) => {
    const d = ago(-i), k = ymd(d), hs = S.habits.filter(h => due(h, d)).sort(byTime);
    return `<li class="day ${i === 0 ? 'now' : ''}"><div class="dh"><strong>${i === 0 ? 'Today' : i === 1 ? 'Tomorrow' : d.toLocaleDateString(undefined, { weekday: 'long' })}</strong><span>${d.toLocaleDateString(undefined, { month: 'short', day: 'numeric' })}</span></div>
      ${hs.length ? hs.map(h => chip(h, k)).join('') : '<p class="muted">Nothing planned</p>'}</li>`;
  }).join('');
}

function renderMonth() {
  const b = new Date(); b.setDate(1); b.setMonth(b.getMonth() + mOff);
  const y = b.getFullYear(), m = b.getMonth(), n = new Date(y, m + 1, 0).getDate(), t = today();
  $('#mTitle').textContent = b.toLocaleDateString(undefined, { month: 'long', year: 'numeric' });
  let html = '<span></span>'.repeat((b.getDay() + 6) % 7);
  for (let day = 1; day <= n; day++) {
    const d = new Date(y, m, day), k = ymd(d), hs = S.habits.filter(h => due(h, d));
    html += `<button class="mc ${k === t ? 'today' : ''} ${k === sel ? 'sel' : ''}" data-day="${k}"><b>${day}</b><span>${hs.map(h => `<i class="${done(h, k) ? 'on' : ''}" style="--c:${h.color || '#2D5BFF'}"></i>`).join('')}</span></button>`;
  }
  $('#mGrid').innerHTML = html;
  $('#mDay').textContent = new Date(sel + 'T00:00').toLocaleDateString(undefined, { weekday: 'long', month: 'long', day: 'numeric' });
  const sd = new Date(sel + 'T00:00'), list = S.habits.filter(h => due(h, sd)).sort(byTime);
  $('#mDetail').innerHTML = list.length ? list.map(h => chip(h, sel)).join('') : '<p class="muted">Nothing planned for this day.</p>';
}

// ---- Actions (saved on this device first, then synced) ----
function toggle(id) {
  const h = S.habits.find(x => String(x.id) === id), d = today(), v = !done(h, d);
  h.logs = v ? [...h.logs, d] : h.logs.filter(x => x !== d);
  S.queue.push({ t: 'log', id: h.id, date: d, done: v });
  save(); render(); flush();
}
function addHabit(title, time, frequency, color, days) {
  const id = 't' + Date.now();
  S.habits.push({ id, title, time, frequency, color, days, created: today(), logs: [] });
  S.queue.push({ t: 'add', id, title, time, frequency, color, days });
  save(); render(); flush();
}
function removeHabit(id) {
  S.habits = S.habits.filter(h => String(h.id) !== id);
  if (id[0] === 't') S.queue = S.queue.filter(q => String(q.id) !== id);
  else S.queue.push({ t: 'del', id });
  save(); render(); flush();
}

// ---- Sync ----
const call = (m, p, b) => fetch('/api' + p, {
  method: m, body: b ? JSON.stringify(b) : undefined,
  headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + A.token },
});
async function flush() {
  if (flushing || !navigator.onLine || !A) return;
  flushing = true;
  try {
    while (S.queue.length) {
      const o = S.queue[0]; let r;
      if (o.t === 'add') r = await call('POST', '/habits', { title: o.title, time: o.time, frequency: o.frequency, color: o.color, days: o.days });
      else if (o.t === 'del') r = await call('DELETE', '/habits/' + o.id);
      else r = await call('PUT', `/habits/${o.id}/log`, { date: o.date, done: o.done });
      if (r.status === 401) { flushing = false; return logout(); }
      if (r.status >= 500) throw new Error('server');
      if (o.t === 'add' && r.ok) {
        const old = o.id, { id } = await r.json();
        S.habits.forEach(h => { if (h.id === old) h.id = id; });
        S.queue.forEach(q => { if (q.id === old) q.id = id; });
      }
      S.queue.shift(); save();
    }
    const r = await call('GET', '/habits');
    if (r.status === 401) { flushing = false; return logout(); }
    if (r.ok && !S.queue.length) { S.habits = await r.json(); save(); }
  } catch (e) { /* offline or server down: keep the queue and retry later */ }
  flushing = false; render();
}

// ---- Reminders (while the app is open) ----
const fired = JSON.parse(localStorage.getItem('et-fired') || '{}');
setInterval(() => {
  if (!A || !S || !('Notification' in window) || Notification.permission !== 'granted') return;
  const now = new Date(), hm = pad(now.getHours()) + ':' + pad(now.getMinutes()), t = today();
  S.habits.forEach(h => {
    const k = h.id + t;
    if (h.time === hm && due(h, now) && !done(h, t) && !fired[k]) {
      fired[k] = 1; localStorage.setItem('et-fired', JSON.stringify(fired));
      new Notification('Time for: ' + h.title, { body: 'Open EasyTask and tap to mark it done.' });
    }
  });
}, 20000);
const showNotify = () => { $('#notify').hidden = !('Notification' in window) || Notification.permission !== 'default'; };

// ---- Wiring ----
$('#swatches').innerHTML = COLORS.map((c, i) => `<label class="sw" style="--c:${c}"><input type="radio" name="color" value="${c}" ${i ? '' : 'checked'} aria-label="Color ${i + 1}"><i></i></label>`).join('');

$('#dayPick .chips').innerHTML = [1, 2, 3, 4, 5, 6, 0].map(v => `<label class="wd"><input type="checkbox" name="wd" value="${v}"><span>${DN[v]}</span></label>`).join('');
const toggleFreq = () => { const v = $('#form [name=frequency]').value; $('#dayPick').hidden = v !== 'custom'; $('#mdWrap').hidden = v !== 'monthly'; };
$('#form [name=frequency]').addEventListener('change', toggleFreq);

document.addEventListener('click', e => {
  const c = e.target.closest('.check'), d = e.target.closest('.del'), tb = e.target.closest('[data-tab]'),
    m = e.target.closest('[data-mode]'), o = e.target.closest('[data-out]'), mn = e.target.closest('[data-m]'), md = e.target.closest('[data-day]');
  if (c) toggle(String(c.dataset.id));
  if (d && confirm('Delete this habit?')) removeHabit(String(d.dataset.id));
  if (o) logout();
  if (mn) { mOff += +mn.dataset.m; renderMonth(); }
  if (md) { sel = md.dataset.day; renderMonth(); }
  if (tb) {
    document.querySelectorAll('[data-tab]').forEach(b => b.setAttribute('aria-selected', b === tb));
    ['today', 'week', 'month', 'progress', 'habits'].forEach(n => $('#p-' + n).hidden = n !== tb.dataset.tab);
  }
  if (m) {
    mode = m.dataset.mode; const reg = mode === 'register';
    document.querySelectorAll('[data-mode]').forEach(b => b.setAttribute('aria-selected', b === m));
    $('#nameField').hidden = !reg; $('#nameField input').required = reg;
    $('#authTitle').textContent = reg ? 'Create your account' : 'Welcome back';
    $('#authSub').textContent = reg ? 'It takes less than a minute.' : "Log in to see today's habits.";
    $('#authBtn').textContent = reg ? 'Create account' : 'Log in';
    $('#authErr').textContent = '';
  }
});
$('#authForm').addEventListener('submit', async e => {
  e.preventDefault(); $('#authErr').textContent = '';
  try {
    const r = await fetch('/api/' + mode, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(Object.fromEntries(new FormData(e.target))) });
    const d = await r.json();
    if (!r.ok) return void ($('#authErr').textContent = d.error || 'Something went wrong.');
    A = d; localStorage.setItem('et-auth', JSON.stringify(A)); e.target.reset(); boot();
  } catch { $('#authErr').textContent = 'Cannot reach the server. Check that it is running and that you are online.'; }
});
$('#form').addEventListener('submit', e => {
  e.preventDefault();
  const f = new FormData(e.target);
  const fr = f.get('frequency'); let days = null;
  if (fr === 'custom') { days = f.getAll('wd').join(','); if (!days) return alert('Pick at least one day.'); }
  if (fr === 'monthly') days = String(Math.min(31, Math.max(1, +f.get('md') || 1)));
  addHabit(f.get('title').trim(), f.get('time'), fr, f.get('color'), days);
  e.target.reset(); toggleFreq();
  document.querySelector('[data-tab=today]').click();
});
$('#notify').addEventListener('click', () => Notification.requestPermission().then(showNotify));
addEventListener('online', flush); addEventListener('offline', () => A && render());
if ('serviceWorker' in navigator) navigator.serviceWorker.register('sw.js');
boot();
