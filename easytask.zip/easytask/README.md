# EasyTask Habit Tracker
HTML/CSS/JavaScript frontend, Node.js + Express REST API, MySQL database, account login (bcrypt + JWT).

## Database (MySQL Workbench)
- New install: File > Open SQL Script > `schema.sql` > lightning bolt.
- Already ran the old schema: open `upgrade.sql` instead and run it once.

## Run
1. Copy `.env.example` to `.env` and fill in your MySQL password and any long text for JWT_SECRET.
2. `npm install` then `npm start`
3. Open http://localhost:3000 and register an account.

## API
POST /api/register, POST /api/login (public). Everything under /api/habits needs the login token.
