require('dotenv').config();
const express = require('express');
const mysql = require('mysql2/promise');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const path = require('path');

const db = mysql.createPool({
  host: process.env.DB_HOST || 'localhost',
  user: process.env.DB_USER || 'root',
  password: process.env.DB_PASSWORD || '',
  database: process.env.DB_NAME || 'easytask',
  dateStrings: true,
  connectionLimit: 10,
});
const SECRET = process.env.JWT_SECRET || 'dev-secret-change-me';
const FREQ = ['daily', 'weekdays', 'weekends', 'custom', 'monthly'];
const okDays = (f, d) => f === 'custom' ? /^[0-6](,[0-6]){0,6}$/.test(d || '') : f === 'monthly' ? /^([1-9]|[12]\d|3[01])$/.test(String(d)) : true;
const app = express();
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

const wrap = fn => (req, res) => fn(req, res).catch(e => {
  console.error(e);
  res.status(500).json({ error: 'Server error' });
});
const sign = u => jwt.sign({ id: u.id }, SECRET, { expiresIn: '30d' });
const pub = u => ({ id: u.id, name: u.name, email: u.email });

// ---- Accounts ----
app.post('/api/register', wrap(async (req, res) => {
  const name = (req.body.name || '').trim().slice(0, 80);
  const email = (req.body.email || '').trim().toLowerCase();
  const pw = req.body.password || '';
  if (!name || !/^\S+@\S+\.\S+$/.test(email) || pw.length < 6)
    return res.status(400).json({ error: 'Enter your name, a valid email, and a password of at least 6 characters.' });
  const [dup] = await db.query('SELECT id FROM users WHERE email=?', [email]);
  if (dup.length) return res.status(409).json({ error: 'That email is already registered. Try logging in.' });
  const [r] = await db.query('INSERT INTO users (name,email,password_hash) VALUES (?,?,?)',
    [name, email, await bcrypt.hash(pw, 10)]);
  const u = { id: r.insertId, name, email };
  res.status(201).json({ token: sign(u), user: pub(u) });
}));

app.post('/api/login', wrap(async (req, res) => {
  const email = (req.body.email || '').trim().toLowerCase();
  const [rows] = await db.query('SELECT * FROM users WHERE email=?', [email]);
  const u = rows[0];
  if (!u || !u.password_hash || !(await bcrypt.compare(req.body.password || '', u.password_hash)))
    return res.status(401).json({ error: 'Email or password is incorrect.' });
  res.json({ token: sign(u), user: pub(u) });
}));

const auth = (req, res, next) => {
  try { req.uid = jwt.verify((req.headers.authorization || '').replace('Bearer ', ''), SECRET).id; next(); }
  catch { res.status(401).json({ error: 'Please log in.' }); }
};
app.use('/api/habits', auth);

// ---- Habits (each user only sees their own) ----
app.get('/api/habits', wrap(async (req, res) => {
  const [habits] = await db.query(
    `SELECT id, title, TIME_FORMAT(target_time,'%H:%i') AS time, frequency, days, color, DATE(created_at) AS created
     FROM habits WHERE user_id=? AND archived=0 ORDER BY target_time, id`, [req.uid]);
  const [logs] = await db.query(
    `SELECT l.habit_id, l.log_date FROM habit_logs l JOIN habits h ON h.id=l.habit_id
     WHERE h.user_id=? AND l.log_date >= CURDATE() - INTERVAL 90 DAY`, [req.uid]);
  habits.forEach(h => { h.logs = logs.filter(l => l.habit_id === h.id).map(l => l.log_date); });
  res.json(habits);
}));

app.post('/api/habits', wrap(async (req, res) => {
  const { title, time = '08:00', frequency = 'daily', color = '#2D5BFF', days = null } = req.body;
  if (!title || !title.trim() || !FREQ.includes(frequency) || !/^\d{2}:\d{2}$/.test(time) || !/^#[0-9a-f]{6}$/i.test(color) || !okDays(frequency, days))
    return res.status(400).json({ error: 'Invalid habit' });
  const [r] = await db.query(
    'INSERT INTO habits (user_id,title,target_time,frequency,days,color) VALUES (?,?,?,?,?,?)',
    [req.uid, title.trim().slice(0, 120), time + ':00', frequency, ['custom', 'monthly'].includes(frequency) ? String(days) : null, color]);
  res.status(201).json({ id: r.insertId });
}));

app.delete('/api/habits/:id', wrap(async (req, res) => {
  await db.query('UPDATE habits SET archived=1 WHERE id=? AND user_id=?', [req.params.id, req.uid]);
  res.json({ ok: true });
}));

app.put('/api/habits/:id/log', wrap(async (req, res) => {
  const { date, done } = req.body;
  if (!/^\d{4}-\d{2}-\d{2}$/.test(date)) return res.status(400).json({ error: 'Invalid date' });
  const [own] = await db.query('SELECT id FROM habits WHERE id=? AND user_id=?', [req.params.id, req.uid]);
  if (!own.length) return res.status(404).json({ error: 'Not found' });
  if (done) await db.query('INSERT IGNORE INTO habit_logs (habit_id,log_date) VALUES (?,?)', [req.params.id, date]);
  else await db.query('DELETE FROM habit_logs WHERE habit_id=? AND log_date=?', [req.params.id, date]);
  res.json({ ok: true });
}));

const port = process.env.PORT || 3000;
app.listen(port, () => console.log(`EasyTask running at http://localhost:${port}`));
