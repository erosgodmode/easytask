-- Run ONCE in MySQL Workbench (adds custom days and monthly habits)
USE easytask;
ALTER TABLE habits MODIFY frequency ENUM('daily','weekdays','weekends','custom','monthly') NOT NULL DEFAULT 'daily';
ALTER TABLE habits ADD COLUMN days VARCHAR(20) NULL;
